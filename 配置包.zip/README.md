# 一人商业研究工作室

这是一个 Office Raccoon 专家团配置包。

## 文件

- `preview.html`：给人看的预览，包含简介、成员、流程、可见规则、交付格式和依赖技能。
- `manifest.json`：给应用导入用的完整配置，包含隐藏执行规则和运行时字段。
- `README.md`：当前说明。

## 导入

在 Office Raccoon 的专家中心点击“导入配置包”，选择这个 ZIP 文件。

导入时会创建“我的专家团”副本，不会覆盖已有配置。同名会自动追加“（导入）”。

## 依赖技能

- artifacts-builder
- business-diagnosis-engine
- business-research-engine
- credibility-auditor
- cross-verification
- dashboard-builder
- data-dashboard
- enterprise-lookup
- html-templates
- knowledge-base
- memory-guide
- pptx
- research-to-deck-outline
- studio-analytics
- trend-detector

## 隐藏执行规则

该配置包包含 3 条隐藏执行规则。预览页不会展开这些规则，应用导入时会从 `manifest.json` 恢复。
